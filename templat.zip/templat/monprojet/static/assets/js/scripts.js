// Script pour le menu déroulant (sitebar)
function toggleSidebar() {
const sidebar = document.getElementById('sidebar');
const topbar = document.getElementById('topbar');
const content = document.getElementById('main-content');

if (sidebar.style.marginLeft === "-220px") {
    sidebar.style.marginLeft = "0";
    topbar.classList.remove("full");
    content.classList.remove("full");
} else {
    sidebar.style.marginLeft = "-220px";
    topbar.classList.add("full");
    content.classList.add("full");
}
}

// Script pour le graphique
        
var ctxBar = document.getElementById('barChart').getContext('2d');
var barChart = new Chart(ctxBar, {
    type: 'bar',
    data: {
    labels: ['Produit A', 'Produit B', 'Produit C', 'Produit D', 'Produit E'],
    datasets: [{
        label: 'Ventes',
        data: [50, 75, 60, 90, 120],
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1
    }]
    },
    options: {
    responsive: true,
    scales: {
        y: {
        beginAtZero: true
        }
    }
    }
});

var ctxPie = document.getElementById('pieChart').getContext('2d');
var pieChart = new Chart(ctxPie, {
    type: 'pie',
    data: {
    labels: ['Catégorie 1', 'Catégorie 2', 'Catégorie 3', 'Catégorie 4'],
    datasets: [{
        data: [30, 50, 40, 80],
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4CAF50'],
        hoverOffset: 4
    }]
    },
    options: {
    responsive: true
    }
});


// Script pour la Modale de Produit 

document.getElementById('addProductForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var productName = document.getElementById('productName').value;
    var productPrice = document.getElementById('productPrice').value;

    alert('Produit ajouté: ' + productName + ' - ' + productPrice + ' €');

    var myModal = new bootstrap.Modal(document.getElementById('addProductModal'));
    myModal.hide();
});

// Gestion de l'animation de la barre latérale
document.getElementById('toggleSidebar').addEventListener('click', function() {
    var sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('minimized');
});
        